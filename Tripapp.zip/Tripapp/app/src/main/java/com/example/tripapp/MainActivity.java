package com.example.tripapp;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.saservice.IRemoteService;

import java.util.List;

public class MainActivity extends AppCompatActivity implements ServiceConnection {

    private static final String TAG = "Trip_app";
    private IRemoteService mService = null;
    Context context;

    //private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className,
                                       IBinder boundService) {
            mService = IRemoteService.Stub.asInterface(boundService);
            Log.d(TAG, "mService: " + mService);
            /*try {
                if (mService != null) {
                    mService.setSurface();
                    //Log.d(TAG, "surface: " + mSurface);
                } else {
                    Log.e(TAG, "mService is null");
                }
            } catch (RemoteException e) {
                e.printStackTrace();
            }*/
            Toast.makeText(MainActivity.this, R.string.service_connected,
                    Toast.LENGTH_SHORT).show();
        }

        public void onServiceDisconnected(ComponentName className) {
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            mService = null;
            // As part of the sample, tell the user what happened.
            Toast.makeText(MainActivity.this, R.string.service_disconnected,
                    Toast.LENGTH_SHORT).show();
        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void bindToService() {
        Intent intent = new Intent("SA_service");
        intent.setPackage("com.example.saservice");
        boolean ret = bindService(intent, this, Context.BIND_AUTO_CREATE);
        Log.d(TAG, "service connection: " + ret);
    }

        /*public static Intent createExplicitFromImplicitIntent(Context context, Intent implicitIntent) {
            PackageManager pm = context.getPackageManager();
            Intent explicitIntent;
            List<ResolveInfo> resolveInfo = pm.queryIntentServices(implicitIntent, 0);
            if (resolveInfo == null || resolveInfo.size() != 1) {
                Log.e(TAG, "resolveInfo is null!!!");
                return null;
            }
            ResolveInfo serviceInfo = resolveInfo.get(0);
            String packageName = serviceInfo.serviceInfo.packageName;
            String className = serviceInfo.serviceInfo.name;
            Log.i(TAG, "packageName:" + packageName + " className:" + className);
            try {
                ComponentName component = new ComponentName(packageName, className);
                if (component !=null) {
                    Log.d(TAG, "service component: " + component);
                    explicitIntent = new Intent(implicitIntent);
                    explicitIntent.setComponent(component);
                    return explicitIntent;
                } else {
                    return null;
                }

            } catch (Exception e) {
                Log.e(TAG, "Exception: " + e);
            }
            return null;
        }*/

    @Override
    protected void onStart() {
        super.onStart();
        bindToService();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(this);
        //mConnection = null;
    }
}